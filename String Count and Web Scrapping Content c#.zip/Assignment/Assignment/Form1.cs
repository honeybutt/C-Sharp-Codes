﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Assignment
{
    /*   public static class StringExtendsionsMethods
       {
           public static String ReplaceWholeWord(this String s, String word, String bywhat)
           {
               char firstLetter = word[0];
               StringBuilder sb = new StringBuilder();
               bool previousWasLetterOrDigit = false;
               int i = 0;
               while (i < s.Length - word.Length + 1)
               {
                   bool wordFound = false;
                   char c = s[i];
                   if (c == firstLetter)
                       if (!previousWasLetterOrDigit)
                           if (s.Substring(i, word.Length).Equals(word))
                           {
                               wordFound = true;
                               bool wholeWordFound = true;
                               if (s.Length > i + word.Length)
                               {
                                   if (Char.IsLetterOrDigit(s[i + word.Length]))
                                       wholeWordFound = false;
                               }

                               if (wholeWordFound)
                                   sb.Append(bywhat);
                               else
                                   sb.Append(word);

                               i += word.Length;
                           }

                   if (!wordFound)
                   {
                       previousWasLetterOrDigit = Char.IsLetterOrDigit(c);
                       sb.Append(c);
                       i++;
                   }
               }

               if (s.Length - i > 0)
                   sb.Append(s.Substring(i));

               return sb.ToString();
           }
       */



    public partial class Form1 : Form
    {
        string s;
        string downloadString;
        int lineCount;
        

        public Form1()
        {
            InitializeComponent();
            this.BackColor = Color.FromArgb(255, 232, 232);
            this.Text ="Assignment";
          
           if (label3.Visible=true)
            {
                label3.Visible = false;
            }
            if(label2.Visible=true)
            {
                label2.Visible = false;
            }
            box.Enabled = false;//for Disable editing something in TExtbox
            rBox.Enabled = false;
        }
       
        private static Regex oClearHtmlScript = new Regex(@"<(.|\n)*?>", RegexOptions.Compiled);

        public static string RemoveAllHTMLTags(string sHtml)
        {
            if (string.IsNullOrEmpty(sHtml))
                return string.Empty;

            return oClearHtmlScript.Replace(sHtml, string.Empty);


        }

        public void GetWordCount(RichTextBox rtb)//For Counting Words
        {
            var text = rtb.Text.Trim();
            int wordCount = 0, index = 0;

            while (index < text.Length)
            {
                // check if current char is part of a word
                while (index < text.Length && !char.IsWhiteSpace(text[index]))
                    index++;

                wordCount++;

                // skip whitespace until next word
                while (index < text.Length && char.IsWhiteSpace(text[index]))
                    index++;
            }
            label3.Text = wordCount.ToString();

        }
        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog gFile = new OpenFileDialog();
            gFile.Filter = "txt files(*.txt)|*.txt|All files(*.*)|*.*";
          
            try
            {

                if (gFile.ShowDialog() == DialogResult.OK)
                {
                    s = File.ReadAllText(gFile.FileName);
                    box.Text = s;
                    box.Enabled = true;
                    lineCount = box.Lines.Count();
                    GetWordCount(box);
                    label2.Text = lineCount.ToString();
                    label3.Visible = true;
                    label2.Visible = true;
                      }
            }
            catch (Exception)
            {
                MessageBox.Show("Error");
            }
        }

        private void box_TextChanged(object sender, EventArgs e)
        {
        }

        private void oldText_TextChanged(object sender, EventArgs e)
        {

        }


        private void button2_Click(object sender, EventArgs e)
        {
            rBox.Enabled = true;
            //string ol,ne;
            //ol=oldText.ToString();
            // ne=newText.ToString();
            //    box.Rtf = box.Rtf.Replace(oldText.ToString(),newText.ToString());
            //box.Rtf = box.Rtf.Replace(oldText.Text.ToString(), newText.Text.ToString());
            if (string.IsNullOrWhiteSpace(oldText.Text) || string.IsNullOrWhiteSpace(box.Text))
            {
                MessageBox.Show("Error,No Word Input");
            }
           if (string.IsNullOrWhiteSpace(newText.Text))
            {
                MessageBox.Show("Error,No Replace word Given");
            }
            else { 
            rBox.Rtf = box.Rtf.Replace(oldText.Text.ToString() + " ", " " + newText.Text.ToString());
            }




            //box.Rtf = box.Rtf.Replace(ol, ne);

            //rBox.Text = box.Rtf;


            //var regExp = new System.Text.RegularExpressions.Regex(@oldText + @"\b"); 
            //box.Rtf = regExp.Replace(box.Rtf, newText.ToString());
            // StringExtendsionsMethods.ReplaceWholeWord(s, oldText.ToString(), newText.ToString());
            //box.Rtf = box.Rtf.Replace(" " + oldText.Text.ToString() + " ", newText.Text.ToString());

            //box.Text = Regex.Replace(box.Text, oldText.ToString(), newText.ToString());
            // s = box.Rtf.Replace(oldText.Text.ToString(), newText.Text.ToString());

            //box.Text = //s.StartsWith(oldText) || s.StartsWith(newText);
            //string input = oldText.ToString();
            //string pattern = @oldText.ToString();
            //string replace = newText.ToString();
            //string result = Regex.Replace(input, pattern, replace);
            //Console.WriteLine(result)
            //box.Text = result.ToString();
            //s.StartsWith(oldText.ToString())
            //ol.StartsWith("") || ol.StartsWith("");
            //box.Rtf = box.Rtf.Replace(ol,ne);

        }

        private void label3_Click(object sender, EventArgs e)
        {
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                WebClient client = new WebClient();
                downloadString = client.DownloadString("https://www.lipsum.com/"); // box.Text = downloadString;

                RemoveAllHTMLTags(downloadString);
                box.Text = RemoveAllHTMLTags(downloadString);
                lineCount = box.Lines.Count();
                GetWordCount(box);

                //
                // Do other things
                //
                label2.Text = lineCount.ToString();
            }
            catch(Exception)
            {
                MessageBox.Show("Internet Problem"+"Error");
            }
           // label3.Visible = true;
     

            /*
                WebRequest request = WebRequest.Create("https://www.lipsum.com/");
                WebResponse response = request.GetResponse();
                Stream data = response.GetResponseStream();
                string html = String.Empty;
                using (StreamReader sr = new StreamReader(data))
                {
                    html = sr.ReadToEnd();
                }*/

            // box.Text = html;


        }

        private void button4_Click(object sender, EventArgs e)
        {
            DirectoryInfo di = new DirectoryInfo(@"D:\");
            FileInfo[] fi = di.GetFiles();
            FileInfo[] fiFiltered = di.GetFiles("*.txt");
            FileInfo[] fiFilteredAndSearchOption = di.GetFiles("*.txt", SearchOption.AllDirectories);
           
        }

       
    }
}
